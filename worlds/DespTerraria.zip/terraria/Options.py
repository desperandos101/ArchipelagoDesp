from dataclasses import dataclass
from Options import Choice, DeathLink, PerGameCommonOptions


class Goal(Choice):
    """The victory condition for your run. Stuff after the goal will not be shuffled."""

    display_name = "Goal"
    option_wall_of_flesh = 0
    option_mechanical_bosses = 1
    # option_calamitas_clone = 2
    option_plantera = 3
    option_golem = 4
    option_empress_of_light = 5
    option_lunatic_cultist = 6
    # option_astrum_deus = 7
    option_moon_lord = 8
    # option_providence_the_profaned_goddess = 9
    # option_devourer_of_gods = 10
    # option_yharon_dragon_of_rebirth = 11
    option_zenith = 12
    # option_calamity_final_bosses = 13
    # option_adult_eidolon_wyrm = 14
    default = 0


class BiomeLocks(Choice):
    """
    Locks biome-specific rewards behind Biome Lock items.
    Only enable this option if you are also enabling extra check options (e.g. Achievements)
    """

    display_name = "Biome Locks"
    option_none = 0
    option_all = 1
    default = 1


class Achievements(Choice):
    """
    Adds checks upon collecting achievements. Achievements for clearing bosses and events are excluded.
    "Exclude Grindy" also excludes fishing achievements.
    """

    display_name = "Achievements"
    option_none = 0
    option_exclude_grindy = 1
    option_exclude_fishing = 2
    option_all = 3
    default = 1


class Chests(Choice):
    """
    Randomizes primary chest items.
    """
    display_name = "Chests"
    option_none = 0
    option_all = 1
    default = 1


class FillExtraChecksWith(Choice):
    """
    Applies if you have extra check options enabled. "Useful Items" helps to make the early game less grindy.
    Items are rewarded to all players in your Terraria world.
    """

    display_name = "Fill Extra Checks With"
    option_coins = 0
    option_useful_items = 1
    default = 1


class ReceiveDangerousEventsAsItems(Choice):
    """
    If "all" is enabled, certain progression items (such as hardmode or invasions) will be received as consumables.
    These consumables can be used at any time to summon the event in question.

    If "none" is enabled, dangerous events will commence the moment they are received.
    However, hardmode invasions will not occuusr in pre-hardmode.
    """

    display_name = "Receive Dangerous Events As Items"
    option_none = 0
    option_all = 2
    default = 2

@dataclass
class TerrariaOptions(PerGameCommonOptions):
    goal: Goal
    biome_locks: BiomeLocks
    achievements: Achievements
    chest_checks: Chests
    fill_extra_checks_with: FillExtraChecksWith
    death_link: DeathLink
    events_as_items: ReceiveDangerousEventsAsItems
